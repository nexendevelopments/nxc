<?php
namespace dhope0000\LXDClient\Constants;

class BackupStrategies
{
    const IMPORT_AND_DELETE = 1;
}
