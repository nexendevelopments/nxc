<?php
namespace dhope0000\LXDClient\Constants;

class LxdRecursionLevels
{
    public const INSTANCE_FULL_RECURSION = 2;
    public const INSTANCE_HALF_RECURSION = 1;
    public const INSTANCE_NO_RECURSION = 0;
}
