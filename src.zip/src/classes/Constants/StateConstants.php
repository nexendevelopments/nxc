<?php
namespace dhope0000\LXDClient\Constants;

class StateConstants
{
    const START = "start";
    const STOP = "stop";
    const RESTART = "restart";
    const FREEZE = "freeze";
    const UNFREEZE = "unfreeze";
}
