<?php
namespace dhope0000\LXDClient\Constants;

class InstanceSettingsKeys
{
    const INSTANCE_IP = 1;
    const RECORD_ACTIONS = 2;
    const BACKUP_DIRECTORY = 3;
}
