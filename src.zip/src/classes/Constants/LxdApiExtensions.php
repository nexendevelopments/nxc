<?php
namespace dhope0000\LXDClient\Constants;

class LxdApiExtensions
{
    const CONTAINER_BACKUP = "container_backup";
    const VIRTUAL_MACHINES = "virtual-machines";
    const CONTAINER_FULL = "container_full";
}
