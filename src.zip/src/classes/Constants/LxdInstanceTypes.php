<?php
namespace dhope0000\LXDClient\Constants;

class LxdInstanceTypes
{
    public const VM = "virtual-machine";
    public const CONTAINER = "container";
}
