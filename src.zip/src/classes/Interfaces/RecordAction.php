<?php

namespace dhope0000\LXDClient\Interfaces;

interface RecordAction
{
}
