<?php

namespace dhope0000\LXDClient\Tools\Instances\Metrics;

use dhope0000\LXDClient\Objects\Host;

class DeployGenericPullProfile
{
    public function deploy(Host $host)
    {
        try {
            $host->profiles->info("nexenCloudPullMetrics");
            return true;
        } catch (\Throwable $e) {
            return $this->deployProfile($host);
        }
    }

    private function deployProfile($host)
    {
        return $host->profiles->create("nexenCloudPullMetrics", "Indicates NexenCloud should pull metrics from these instances", [
            "environment.nexenCloudPullMetrics"=>"y"
        ]);
    }
}
