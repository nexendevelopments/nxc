<?php
namespace dhope0000\LXDClient\Controllers\Hosts;

use dhope0000\LXDClient\Tools\Hosts\GetHostOverview;
use dhope0000\LXDClient\Objects\Host;

class GetHostOverviewController
{
    public function __construct(GetHostOverview $getHostOverview)
    {
        $this->getHostOverview = $getHostOverview;
    }

    public function get(Host $host)
    {
        return $this->getHostOverview->get($host);
    }
}
