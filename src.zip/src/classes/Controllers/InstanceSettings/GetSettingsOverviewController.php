<?php

namespace dhope0000\LXDClient\Controllers\InstanceSettings;

use dhope0000\LXDClient\Tools\InstanceSettings\GetSettingsOverview;
use Symfony\Component\Routing\Annotation\Route;

class GetSettingsOverviewController implements \dhope0000\LXDClient\Interfaces\RecordAction
{
    private $getSettingsOverview;

    public function __construct(GetSettingsOverview $getSettingsOverview)
    {
        $this->getSettingsOverview = $getSettingsOverview;
    }
    /**
     * @Route("", name="Get NEXENCloud Settings Overview")
     */
    public function get()
    {
        return $this->getSettingsOverview->get();
    }
}
